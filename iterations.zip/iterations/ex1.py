# KILLIAN CLOTAGATIDE / Iterations : Ex 1

nb = int(input("Entrez le nombre entier a multiplier : "))

# m pour multiplicateur
for m in range(11):
    produit = m*nb
    print(nb,"*",m,"=",produit)